package entidade;

import main.GamePanel;
import main.UtilityTool;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;

public class Entidade {
	public int solidAreaDefaultX;
	public int solidAreaDefaultY;
	GamePanel gp;
	public int worldX, worldY;
	public int speed;

	public BufferedImage up1, up2, down1, down2, left1, left2, right1, right2;
	public String direcao;

	public int spriteCounter = 0;
	public int spriteNum = 1;
	public Rectangle solidArea = new Rectangle(0,0,48,48);
	public int solidAreaDefaltX,solidAreaDefaltY;
	public boolean collisionOn = false;
	public int  actionLockCounter = 0;
	public String dialogues[] = new String[20];
	int dialogueIndex = 0;




	public Entidade(GamePanel gp){
		this.gp = gp;
	}
	public void setAction(){}
	public void speak(){
		if(dialogues[dialogueIndex]== null){
			dialogueIndex = 0;
		}
		gp.ui.currentDialog = dialogues[dialogueIndex];
		dialogueIndex++;
		switch (gp.player.direcao){
			case "up":
				direcao ="down";
				break;
			case "down":
				direcao = "up";
				break;
			case "left":
				direcao = "right";
				break;
			case "right":
				direcao = "left";
				break;
		}
	}
	public void update(){

		setAction();
		collisionOn = false;
		gp.colisionCheker.checkTile(this);
		gp.colisionCheker.checkObject(this,false);
		gp.colisionCheker.checkPlayer(this);

// IF COLLISION IS FALSE, PLAYER CAN MOVE
		if (!collisionOn) {
			switch (direcao) {
				case "up":
					worldY -= speed;
					break;
				case "down":
					worldY += speed;
					break;
				case "left":
					worldX -= speed;
					break;
				case "right":
					worldX += speed;
					break;
			}
		}

		spriteCounter++;
		if (spriteCounter > 12) {
			spriteNum = spriteNum == 1 ? 2 : 1;
			spriteCounter = 0;
		}

	}
	public void draw(Graphics2D g2){
		BufferedImage image = null;
		int screenX = worldX - gp.player.worldX + gp.player.screenX;
		int screenY = worldY - gp.player.worldY + gp.player.screenY;

		if(worldX + gp.tileSize > gp.player.worldX - gp.player.screenX &&
				worldX - gp.tileSize < gp.player.worldX + gp.player.screenX &&
				worldY + gp.tileSize > gp.player.worldY - gp.player.screenY &&
				worldY - gp.tileSize < gp.player.worldY + gp.player.screenY) {
			switch (direcao) {
				case "up":
					image = (spriteNum == 1) ? up1 : up2;
					break;
				case "down":
					image = (spriteNum == 1) ? down1 : down2;
					break;
				case "left":
					image = (spriteNum == 1) ? left1 : left2;
					break;
				case "right":
					image = (spriteNum == 1) ? right1 : right2;
					break;
			}

			g2.drawImage(image, screenX, screenY, gp.tileSize,gp.tileSize,null);
		}
	}
	public BufferedImage setup(String imagePath){

		UtilityTool uTool = new UtilityTool();
		BufferedImage image =null;
		try{
			image = ImageIO.read(getClass().getResourceAsStream( imagePath +".png"));
			image = uTool.scaleImage(image,gp.tileSize,gp.tileSize);
		}catch (IOException e){
			e.printStackTrace();
		}
		return image;
	}

}
