package entidade;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

import main.GamePanel;
import main.KeyHandler;
import main.UtilityTool;

public class Player extends Entidade {

	KeyHandler keyH;
	public final int screenX;
	public final int screenY;
	public int hasKeys = 0;
	public Player(GamePanel gp, KeyHandler keyH) {
		super(gp);
		this.keyH = keyH;

		screenX = gp.screenWidth / 2 - (gp.tileSize / 2);
		screenY = gp.screenHeight / 2 - (gp.tileSize / 2);


		solidArea = new Rectangle();
		solidArea.x = 8;
		solidArea.y = 16;
		solidAreaDefaltX = solidArea.x;
		solidAreaDefaltY = solidArea.y;
		solidArea.width = 32;
		solidArea.height = 32;

		setDefaultValues();
		getImagePlayer();
	}

	public void setDefaultValues() {
		worldX = gp.tileSize * 23;
		worldY = gp.tileSize *21;
		speed = 4;
		direcao = "down";
	}

	public void getImagePlayer() {
		up1 = setup("/player/boy_up_1");
		up2 = setup("/player/boy_up_2");
		down1 = setup("/player/boy_down_1");
		down2 = setup("/player/boy_down_2");
		left1 = setup("/player/boy_left_1");
		left2 = setup("/player/boy_left_2");
		right1 = setup("/player/boy_right_1");
		right2 = setup("/player/boy_right_2");
	}

	public void update() {
		if(keyH.upPressed || keyH.downPressed || keyH.leftPressed || keyH.rightPressed) {
			if (keyH.upPressed) {
				direcao = "up";
			} else if (keyH.downPressed) {
				direcao = "down";
			} else if (keyH.leftPressed) {
				direcao = "left";
			} else if (keyH.rightPressed) {
				direcao = "right";
			}

			// CHECK TILE COLLISION
			collisionOn = false;
			gp.colisionCheker.checkTile(this);

			//CHECK OBJ COLLISION
			int objIndex = gp.colisionCheker.checkObject(this, true);
			pickUpObject(objIndex);
			//CHECK NPC COLISION
			int npcIndex = gp.colisionCheker.checkEntity(this,gp.npc);
			interactNPC(npcIndex);

			// IF COLLISION IS FALSE, PLAYER CAN MOVE
			if (!collisionOn) {
				switch (direcao) {
					case "up":
						worldY -= speed;
						break;
					case "down":
						worldY += speed;
						break;
					case "left":
						worldX -= speed;
						break;
					case "right":
						worldX += speed;
						break;
				}
			}

			spriteCounter++;
			if (spriteCounter > 12) {
				spriteNum = spriteNum == 1 ? 2 : 1;
				spriteCounter = 0;
			}

		}else{
			spriteNum =1;
		}
	}
	public void pickUpObject(int i){
	if( i != 999){
		String objName = gp.obj[i].name;
		switch (objName){
			case "Key":
				gp.playSoundEfect(1);
				hasKeys ++;
				gp.obj[i] = null;
				gp.ui.showMessage("Você pegou uma chave!");
				break;
			case "Door":
				if(hasKeys == 2){
					gp.playSoundEfect(2);
					gp.obj[i] = null;
					hasKeys = 0;
					gp.ui.showMessage("Porta destrancada!");
				}else{
					gp.ui.showMessage("Porta trancada");
				}
				break;
			case "Chest":
					gp.ui.gameFinished = true;
					gp.stopMusic();
					gp.playSoundEfect(3);
				break;

		}

		}
	}
public void interactNPC(int i){
		if(i!= 999){
			if(gp.keyH.enterPressed == true){
				gp.gameState = gp.dialogueState;
				gp.npc[i].speak();
			}
		}
		gp.keyH.enterPressed = false;
}
	public void draw(Graphics2D g2) {
		BufferedImage image = null;

		switch (direcao) {
			case "up":
				image = (spriteNum == 1) ? up1 : up2;
				break;
			case "down":
				image = (spriteNum == 1) ? down1 : down2;
				break;
			case "left":
				image = (spriteNum == 1) ? left1 : left2;
				break;
			case "right":
				image = (spriteNum == 1) ? right1 : right2;
				break;
		}

		g2.drawImage(image, screenX, screenY, null);
	}
}