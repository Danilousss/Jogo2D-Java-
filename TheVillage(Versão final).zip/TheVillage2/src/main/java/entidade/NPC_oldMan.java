package entidade;

import main.GamePanel;

import java.util.Random;

public class NPC_oldMan extends Entidade{
public NPC_oldMan(GamePanel gp){
    super(gp);
    direcao = "down";
    speed = 1;

    getImage();
    setDialog();

}
    public void getImage() {
        up1 = setup("/NPC/oldman_up_1");
        up2 = setup("/NPC/oldman_up_2");
        down1 = setup("/NPC/oldman_down_1");
        down2 = setup("/NPC/oldman_down_2");
        left1 = setup("/NPC/oldman_left_1");
        left2 = setup("/NPC/oldman_left_2");
        right1 = setup("/NPC/oldman_right_1");
        right2 = setup("/NPC/oldman_right_2");
    }
    public void setDialog(){
        dialogues[0] = "Olá, jovem viajante! \nEstá pronto para um desafio de conhecimento?";
        dialogues[1] = "Excelente! Aqui vai a primeira pergunta:";
        dialogues[2] = "O que é Java?";
        dialogues[3] = "a) Um tipo de café\nb) Uma linguagem de programação\nc) Um sistema operacional\nd) Um animal";
        dialogues[4] = "Qual é a função do método println() em Java?";
        dialogues[5] = "a) Imprimir uma linha de texto no console\nb) Ler uma linha de texto do teclado\nc) Calcular o valor absoluto de um número\nd) Criar uma nova linha em um arquivo de texto";
        dialogues[6] = "Como se declara uma variável inteira em Java?";
        dialogues[7] = "a) variable int x;\nb) Int x = 5;\nc) String x = 5;\nd) x = 5;";
        dialogues[8] = "Muito bem!, como recompensa vou te \ndizer aonde estão as chaves do tesouro";
        dialogues[9] = "Eu procuraria em algum lugar ao norte perto de um lago";
        dialogues[10] ="A outra chave fica na direção oposta.\nBoa sorte!";
        dialogues[11] = "Encontar o tesouro fica por sua conta";

    }
    public void setAction(){

    actionLockCounter++;
    if(actionLockCounter == 120){
        Random random = new Random();
        int i = random.nextInt(100)+1;
        if(i<=25){
            direcao = "up";
        }if(i>25 && i <= 50){
            direcao = "down";
        }if(i>50 && i <= 75){
            direcao = "left";
        }if(i>75){
            direcao = "right";
        }
        actionLockCounter = 0;
      }
    }
    public void speak(){
        super.speak();
    }


}
