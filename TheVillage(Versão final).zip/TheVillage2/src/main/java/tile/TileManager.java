package tile;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import javax.imageio.ImageIO;

import main.GamePanel;
import main.UtilityTool;

public class TileManager {

	GamePanel gp;
	public Tile [] tile;
	public int mapTileNum [][];
	
	public TileManager(GamePanel gp) {
		this.gp = gp;
		tile = new Tile[50];
		mapTileNum = new int[gp.maxWorldCol][gp.maxWorldRow];
		getTileImage();
		loadMap("/maps/worldV2.txt");

	}
	public void getTileImage() {
        setup(0,"grass00",false);
        setup(1,"grass00",false);
        setup(2,"grass00",false);
        setup(3,"grass00",false);
        setup(4,"grass00",false);
        setup(5,"grass00",false);
		setup(6,"grass00",false);
		setup(7,"grass00",false);
		setup(8,"grass00",false);
		setup(9,"grass00",false);

		setup(10,"grass00",false);
		setup(11,"grass01",false);
		setup(12,"water00",true);
		setup(13,"water01",true);
		setup(14,"water02",true);
		setup(15,"water03",true);
		setup(16,"water04",true);
		setup(17,"water05",true);
		setup(18,"water06",true);
		setup(19,"water07",true);
		setup(20,"water08",true);
		setup(21,"water09",true);
		setup(22,"water10",true);
		setup(23,"water11",true);
		setup(24,"water12",true);
		setup(25,"water13",true);
		setup(26,"road00",false);
		setup(27,"road01",false);
		setup(28,"road02",false);
		setup(29,"road03",false);
		setup(30,"road04",false);
		setup(31,"road05",false);
		setup(32,"road06",false);
		setup(33,"road07",false);
		setup(34,"road08",false);
		setup(35,"road09",false);
		setup(36,"road10",false);
		setup(37,"road11",false);
		setup(38,"road12",false);
		setup(39,"earth",false);
		setup(40,"wall",true);
		setup(41,"tree",true);


//		tile[0] = new Tile();
//		tile[0].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0000.png"));
//
//		tile[1] = new Tile();
//		tile[1].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0043.png"));
//
//		tile[2] = new Tile();
//		tile[2].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0025.png"));
//
//		tile[3] = new Tile();
//		tile[3].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0020.png"));
//
//		tile[4] = new Tile();
//		tile[4].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0019.png"));
//
//		tile[5] = new Tile();
//		tile[5].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0031.png"));
//
//		tile[6] = new Tile();
//		tile[6].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0001.png"));
//
//		tile[7] = new Tile();
//		tile[7].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0028.png"));
//
//		tile[8] = new Tile();
//		tile[8].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0013.png"));
//
//		tile[9] = new Tile();
//		tile[9].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0003.png"));
//
//		tile[10] = new Tile();
//		tile[10].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0015.png"));
//
//		tile[11] = new Tile();
//		tile[11].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0068.png"));
//		tile[11].colisao = true;
//
//		tile[12] = new Tile();
//		tile[12].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0032.png"));
//
//		tile[13] = new Tile();
//		tile[13].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0014.png"));
//
//		tile[14] = new Tile();
//		tile[14].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0026.png"));
//
//		tile[15] = new Tile();
//		tile[15].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0052.png"));
//		tile[15].colisao = true;
//
//		tile[16] = new Tile();
//		tile[16].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0053.png"));
//		tile[16].colisao = true;
//
//		tile[17] = new Tile();
//		tile[17].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0064.png"));
//		tile[17].colisao = true;
//
//		tile[18] = new Tile();
//		tile[18].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0076.png"));
//			tile[18].colisao = true;
//		tile[19] = new Tile();
//		tile[19].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0065.png"));
//		tile[19].colisao = true;
//
//		tile[20] = new Tile();
//		tile[20].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0088.png"));
//			tile[20].colisao = true;
//		tile[21] = new Tile();
//		tile[21].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0089.png"));
//			tile[21].colisao = true;
//		tile[22] = new Tile();
//		tile[22].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0066.png"));
//		tile[22].colisao = true;
//
//		tile[23] = new Tile();
//		tile[23].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0079.png"));
//			tile[23].colisao = true;
//		tile[24] = new Tile();
//		tile[24].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0054.png"));
//		tile[24].colisao = true;
//
//		tile[25] = new Tile();
//		tile[25].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0067.png"));
//		tile[25].colisao = true;
//
//		tile[26] = new Tile();
//		tile[26].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0002.png"));
//
//		tile[27] = new Tile();
//		tile[27].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0048.png"));
//		tile[27].colisao = true;
//
//		tile[28] = new Tile();
//		tile[28].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0060.png"));
//		tile[28].colisao =true;
//
//		tile[29] = new Tile();
//		tile[29].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0072.png"));
//		tile[29].colisao = true;
//		tile[30] = new Tile();
//		tile[30].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0051.png"));
//		tile[30].colisao = true;
//
//		tile[31] = new Tile();
//		tile[31].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0061.png"));
//		tile[31].colisao =true;
//
//		tile[32] = new Tile();
//		tile[32].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0084.png"));
//			tile[32].colisao = true;
//		tile[33] = new Tile();
//		tile[33].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0049.png"));
//		tile[33].colisao = true;
//
//		tile[34] = new Tile();
//		tile[34].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0063.png"));
//		tile[34].colisao = true;
//
//		tile[35] = new Tile();
//		tile[35].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0085.png"));
//			tile[35].colisao = true;
//		tile[36] = new Tile();
//		tile[36].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0050.png"));
//		tile[36].colisao = true;
//
//		tile[37] = new Tile();
//		tile[37].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0062.png"));
//		tile[37].colisao = true;
//
//		tile[38] = new Tile();
//		tile[38].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0075.png"));
//			tile[38].colisao = true;
//		tile[39] = new Tile();
//		tile[39].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0096.png"));
//
//		tile[40] = new Tile();
//		tile[40].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0120.png"));
//			tile[40].colisao = true;
//		tile[41] = new Tile();
//		tile[41].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0126.png"));
//			tile[41].colisao = true;
//		tile[42] = new Tile();
//		tile[42].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0036.png"));
//
//		tile[43] = new Tile();
//		tile[43].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0024.png"));
//
//		tile[44] = new Tile();
//		tile[44].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0037.png"));
//
//		tile[45] = new Tile();
//		tile[45].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0038.png"));
//
//		tile[46] = new Tile();
//		tile[46].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0012.png"));
//
//		tile[47] = new Tile();
//		tile[47].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0004.png"));
//
//		tile[48] = new Tile();
//		tile[48].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0045.png"));
//		tile[48].colisao =true;
//
//		tile[49] = new Tile();
//		tile[49].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0044.png"));
//		tile[49].colisao = true;
//
//		tile[50] = new Tile();
//		tile[50].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0056.png"));
//		tile[50].colisao = true;
//
//		tile[51] = new Tile();
//		tile[51].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0068.png"));
//		tile[51].colisao = true;
//
//		tile[52] = new Tile();
//		tile[52].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0082.png"));
//			tile[52].colisao = true;
//		tile[53] = new Tile();
//		tile[53].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0080.png"));
//			tile[53].colisao = true;
//		tile[54] = new Tile();
//		tile[54].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0094.png"));
//
//		tile[55] = new Tile();
//		tile[55].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0017.png"));
//
//		tile[56] = new Tile();
//		tile[56].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0016.png"));
//
//		tile[57] = new Tile();
//		tile[57].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0092.png"));
//
//		tile[57] = new Tile();
//		tile[57].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0104.png"));
//			tile[57].colisao = true;
//		tile[58] = new Tile();
//		tile[58].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0092.png"));
//
//		tile[59] = new Tile();
//		tile[59].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0027.png"));
//
//		tile[60] = new Tile();
//		tile[60].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0083.png"));
//			tile[60].colisao = true;
//		tile[61] = new Tile();
//		tile[61].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0057.png"));
//		tile[61].colisao = true;
//
//		tile[62] = new Tile();
//		tile[62].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0029.png"));
//
//		tile[63] = new Tile();
//		tile[63].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0095.png"));
//
//		tile[64] = new Tile();
//		tile[64].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0018.png"));
//
//		tile[65] = new Tile();
//		tile[65].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0007.png"));
//
//		tile[66] = new Tile();
//		tile[66].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0127.png"));
//
//		tile[67] = new Tile();
//		tile[67].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0130.png"));
//
//		tile[68] = new Tile();
//		tile[68].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0118.png"));
//
//		tile[69] = new Tile();
//		tile[69].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tile_0105.png"));
    }
	public void setup(int index, String imageName, boolean collision){
		UtilityTool uTool = new UtilityTool();
		try{
			tile[index] = new Tile();
			tile[index].image = ImageIO.read(getClass().getResourceAsStream("/tiles/"+imageName+ ".png"));
			tile[index].image = uTool.scaleImage(tile[index].image,gp.tileSize,gp.tileSize);
			tile[index].colisao = collision;
		}catch (IOException e){
			e.printStackTrace();
		}
	}
	public void loadMap(String path){
	try{
		InputStream is = getClass().getResourceAsStream(path);
		BufferedReader br = new BufferedReader( new InputStreamReader(is));
		int col = 0;
		int row =0;
		while(col<gp.maxWorldCol && row<gp.maxWorldRow){
			String line = br.readLine();
			while (col<gp.maxWorldCol){
				String numbers[] = line.split(" ");
				int num = Integer.parseInt(numbers[col]);
				mapTileNum[col][row] = num;
				col++;
			}
			if(col == gp.maxWorldCol){
				col = 0;
				row ++;
			}
		}
		br.close();

	}catch (Exception e){
	}
	}
	public void draw(Graphics2D g2) {
		int Worldcol = 0;
		int Worldrow = 0;

		while (Worldcol<gp.maxWorldCol && Worldrow <gp.maxWorldRow){

			int tileNum  = mapTileNum[Worldcol][Worldrow];

			int worldX = Worldcol * gp.tileSize;
			int worldY = Worldrow * gp.tileSize;
			int screenX = worldX - gp.player.worldX + gp.player.screenX;
			int screenY = worldY - gp.player.worldY + gp.player.screenY;

			if(worldX + gp.tileSize > gp.player.worldX - gp.player.screenX &&
				worldX - gp.tileSize < gp.player.worldX + gp.player.screenX &&
				worldY + gp.tileSize > gp.player.worldY - gp.player.screenY &&
				worldY - gp.tileSize < gp.player.worldY + gp.player.screenY){

				g2.drawImage(tile[tileNum].image,screenX,screenY,null);
			}
			Worldcol++;
			if(Worldcol ==gp.maxWorldCol){
				Worldcol =0;
				Worldrow++;
			}
		}
	}
}
