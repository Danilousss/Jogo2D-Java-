package main;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Arrays;

//controlar entradas do teclado
public class KeyHandler implements KeyListener {
	GamePanel gp;
	public boolean upPressed, downPressed, leftPressed, rightPressed, enterPressed;
	boolean checkDrawTime = false;
	char[] correctAnswer = {'b','a','c'};

	public KeyHandler(GamePanel gp){
		this.gp = gp;
	}

	@Override
	public void keyTyped(KeyEvent e) {
	}

	@Override
	public void keyPressed(KeyEvent e) {
		int code = e.getKeyCode();
		//PLAY STATE
		if(gp.gameState == gp.playState){
			if(code == KeyEvent.VK_W) {
				upPressed = true;
			}

			if(code == KeyEvent.VK_S) {
				downPressed = true;
			}

			if(code == KeyEvent.VK_A) {
				leftPressed = true;
			}

			if(code == KeyEvent.VK_D) {
				rightPressed = true;

			}
			if(code == KeyEvent.VK_P) {
				gp.gameState = gp.pauseState;
			}
			if(code == KeyEvent.VK_ENTER) {
				enterPressed = true;
				gp.ui.messageON = false;
				char selectedAnswer = '\0';
				switch (gp.ui.currentDialog){
					case "O que é Java?\na) Um tipo de café\nb) Uma linguagem de programação\nc) Um sistema operacional\nd) Um animal":
					case "Qual é a função do método println() em Java?\na) Imprimir uma linha de texto no console\nb) Ler uma linha de texto do teclado\nc) Calcular o valor absoluto de um número\nd) Criar uma nova linha em um arquivo de texto":
					case "Como se declara uma variável inteira em Java?\na) variable int x;\nb) Int x = 5;\nc) int x = 5;\nd) x = 5;":
						if (code == KeyEvent.VK_A){
							selectedAnswer = 'a';
						} else if (code == KeyEvent.VK_B){
							selectedAnswer = 'b';
						} else if(code == KeyEvent.VK_C){
							selectedAnswer = 'c';
						} else if(code == KeyEvent.VK_D){
							selectedAnswer = 'd';
						}
						break;
				}
				if(selectedAnswer != '\0'){
					boolean answerCorrect = false;
					for(char answer : correctAnswer){
						if(selectedAnswer == answer){
							answerCorrect = true;
							break;
						}
					}
					if(answerCorrect){
						gp.ui.showMessage("Resposta Correta!");
					} else {
						gp.ui.showMessage("Resposta Incorreta.");
					}
				}

			}
			//DEBUG
			if(code ==KeyEvent.VK_T){
				if(checkDrawTime == false){
					checkDrawTime = true;
				} else if (checkDrawTime == true) {
					checkDrawTime = false;
				}
			}
		}
		else if(gp.gameState == gp.pauseState){
			if(code == KeyEvent.VK_P) {
				gp.gameState = gp.playState;
			}
		}
		else if (gp.gameState == gp.dialogueState){
			if(code== KeyEvent.VK_ENTER){
				gp.gameState = gp.playState;
			}
		}

	}

	@Override
	public void keyReleased(KeyEvent e) {
		int code = e.getKeyCode();
		if(code == KeyEvent.VK_W) {
			upPressed = false;
		}

		if(code == KeyEvent.VK_S) {
			downPressed = false;
		}

		if(code == KeyEvent.VK_A) {
			leftPressed = false;
		}

		if(code == KeyEvent.VK_D) {
			rightPressed = false;

		}

	}

}
