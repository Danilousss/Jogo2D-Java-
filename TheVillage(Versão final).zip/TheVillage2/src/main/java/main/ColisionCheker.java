package main;

import entidade.Entidade;

public class ColisionCheker {
    GamePanel gp;

    public ColisionCheker(GamePanel gp) {
        this.gp = gp;
    }

    public void checkTile(Entidade entidade) {
        int entityLeftWorldX = entidade.worldX + entidade.solidArea.x;
        int entityRightWorldX = entidade.worldX + entidade.solidArea.x + entidade.solidArea.width;
        int entityTopWorldY = entidade.worldY + entidade.solidArea.y;
        int entityBottomWorldY = entidade.worldY + entidade.solidArea.y + entidade.solidArea.height;

        int entityLeftCol = entityLeftWorldX / gp.tileSize;
        int entityRightCol = entityRightWorldX / gp.tileSize;
        int entityTopRow = entityTopWorldY / gp.tileSize;
        int entityBottomRow = entityBottomWorldY / gp.tileSize;

        int tileNum1 = 0, tileNum2 = 0;

        switch (entidade.direcao) {
            case "up":
                entityTopRow = (entityTopWorldY - entidade.speed) / gp.tileSize;
                tileNum1 = gp.tileM.mapTileNum[entityLeftCol][entityTopRow];
                tileNum2 = gp.tileM.mapTileNum[entityRightCol][entityTopRow];
                if (gp.tileM.tile[tileNum1].colisao || gp.tileM.tile[tileNum2].colisao) {
                    entidade.collisionOn = true;
                }
                break;
            case "down":
                entityBottomRow = (entityBottomWorldY + entidade.speed) / gp.tileSize;
                tileNum1 = gp.tileM.mapTileNum[entityLeftCol][entityBottomRow];
                tileNum2 = gp.tileM.mapTileNum[entityRightCol][entityBottomRow];
                if (gp.tileM.tile[tileNum1].colisao || gp.tileM.tile[tileNum2].colisao) {
                    entidade.collisionOn = true;
                }
                break;
            case "left":
                entityLeftCol = (entityLeftWorldX - entidade.speed) / gp.tileSize;
                tileNum1 = gp.tileM.mapTileNum[entityLeftCol][entityTopRow];
                tileNum2 = gp.tileM.mapTileNum[entityLeftCol][entityBottomRow];
                if (gp.tileM.tile[tileNum1].colisao || gp.tileM.tile[tileNum2].colisao) {
                    entidade.collisionOn = true;
                }
                break;
            case "right":
                entityRightCol = (entityRightWorldX + entidade.speed) / gp.tileSize;
                tileNum1 = gp.tileM.mapTileNum[entityRightCol][entityTopRow];
                tileNum2 = gp.tileM.mapTileNum[entityRightCol][entityBottomRow];
                if (gp.tileM.tile[tileNum1].colisao || gp.tileM.tile[tileNum2].colisao) {
                    entidade.collisionOn = true;
                }
                break;
        }
    }
    public int checkObject(Entidade entidade, boolean player){
        int index = 999;

        for(int i = 0; i <gp.obj.length; i++){
            if(gp.obj[i]!= null){
                //get solid area position
                entidade.solidArea.x = entidade.worldX + entidade.solidArea.x;
                entidade.solidArea.y = entidade.worldY + entidade.solidArea.y;
                // get the objec's solid area
                gp.obj[i].solidArea.x = gp.obj[i].worldX + gp.obj[i].solidArea.x;
                gp.obj[i].solidArea.y = gp.obj[i].worldY + gp.obj[i].solidArea.y;

                switch (entidade.direcao){
                    case"up":
                        entidade.solidArea.y -= entidade.speed;
                        if(entidade.solidArea.intersects(gp.obj[i].solidArea)){
                          if(gp.obj[i].collision == true){
                              entidade.collisionOn = true;
                          }
                          if(player == true){
                              index = i;
                          }
                        }
                        break;
                    case "down":
                        entidade.solidArea.y += entidade.speed;
                        if(entidade.solidArea.intersects(gp.obj[i].solidArea)){
                            if(gp.obj[i].collision == true){
                                entidade.collisionOn = true;
                            }
                            if(player == true){
                                index = i;
                            }
                        }
                        break;
                    case"left":
                        entidade.solidArea.x -= entidade.speed;
                        if(entidade.solidArea.intersects(gp.obj[i].solidArea)){
                            if(gp.obj[i].collision == true){
                                entidade.collisionOn = true;
                            }
                            if(player == true){
                                index = i;
                            }
                        }
                        break;
                    case"right":
                        entidade.solidArea.x += entidade.speed;
                        if(entidade.solidArea.intersects(gp.obj[i].solidArea)){
                            if(gp.obj[i].collision == true){
                                entidade.collisionOn = true;
                            }
                            if(player == true){
                                index = i;
                            }
                            break;
                        }
                }
                entidade.solidArea.x = entidade.solidAreaDefaltX;
                entidade.solidArea.y = entidade.solidAreaDefaltY;
                gp.obj[i].solidArea.x = gp.obj[i].solidAreaDefaultX;
                gp.obj[i].solidArea.y = gp.obj[i].solidAreaDefaultY;
            }
        }
        return index;
    }
    public int  checkEntity(Entidade entidade, Entidade[] target){
        int index = 999;

        for(int i = 0; i <target.length; i++){
            if(target[i]!= null) {
                //get solid area position
                entidade.solidArea.x = entidade.worldX + entidade.solidArea.x;
                entidade.solidArea.y = entidade.worldY + entidade.solidArea.y;
                // get the objec's solid area
                target[i].solidArea.x = target[i].worldX + target[i].solidArea.x;
                target[i].solidArea.y = target[i].worldY + target[i].solidArea.y;

                switch (entidade.direcao) {
                    case "up":
                        entidade.solidArea.y -= entidade.speed;
                        if (entidade.solidArea.intersects(target[i].solidArea)) {
                            entidade.collisionOn = true;
                            index = i;
                        }


                        break;
                    case "down":
                        entidade.solidArea.y += entidade.speed;
                        if(entidade.solidArea.intersects(target[i].solidArea)){
                                entidade.collisionOn = true;
                                index = i;
                            }

                        break;
                    case"left":
                        entidade.solidArea.x -= entidade.speed;
                        if(entidade.solidArea.intersects(target[i].solidArea)){
                                entidade.collisionOn = true;
                                index = i;
                            }

                        break;
                    case"right":
                        entidade.solidArea.x += entidade.speed;
                        if(entidade.solidArea.intersects(target[i].solidArea)){
                                entidade.collisionOn = true;
                                index = i;
                            break;
                        }
                }
                entidade.solidArea.x = entidade.solidAreaDefaltX;
                entidade.solidArea.y = entidade.solidAreaDefaltY;
                target[i].solidArea.x = target[i].solidAreaDefaultX;
                target[i].solidArea.y = target[i].solidAreaDefaultY;
            }
        }
        return index;
    }
    public void checkPlayer(Entidade entidade){
        //get solid area position
        entidade.solidArea.x = entidade.worldX + entidade.solidArea.x;
        entidade.solidArea.y = entidade.worldY + entidade.solidArea.y;
        // get the objec's solid area
        gp.player.solidArea.x = gp.player.worldX + gp.player.solidArea.x;
        gp.player.solidArea.y = gp.player.worldY + gp.player.solidArea.y;

        switch (entidade.direcao) {
            case "up":
                entidade.solidArea.y -= entidade.speed;
                if (entidade.solidArea.intersects(gp.player.solidArea)) {
                    entidade.collisionOn = true;
                }
                break;
            case "down":
                entidade.solidArea.y += entidade.speed;
                if(entidade.solidArea.intersects(gp.player.solidArea)){
                    entidade.collisionOn = true;
                }
                break;
            case"left":
                entidade.solidArea.x -= entidade.speed;
                if(entidade.solidArea.intersects(gp.player.solidArea)){
                    entidade.collisionOn = true;
                }
                break;
            case"right":
                entidade.solidArea.x += entidade.speed;
                if(entidade.solidArea.intersects(gp.player.solidArea)){
                    entidade.collisionOn = true;
                    break;
                }
        }
        entidade.solidArea.x = entidade.solidAreaDefaltX;
        entidade.solidArea.y = entidade.solidAreaDefaltY;
        gp.player.solidArea.x = gp.player.solidAreaDefaultX;
        gp.player.solidArea.y = gp.player.solidAreaDefaultY;
    }
    }

